def greet(filelike):
    filelike.write("Hello world!\n")

