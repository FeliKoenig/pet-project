def greet(filelike):
    filelike.write("Hello world!\n")

def scherestein(name):
    print(name)