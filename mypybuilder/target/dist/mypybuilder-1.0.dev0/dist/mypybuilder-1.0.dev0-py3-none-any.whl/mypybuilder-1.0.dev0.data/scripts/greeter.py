#!/usr/bin/env python
import sys
from myproject import greet

greet(sys.stdout)